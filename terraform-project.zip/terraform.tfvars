region              = "ap-northeast-2"
project_name        = "csh3031"
vpc_cidr            = "172.16.0.0/16"
azs                 = ["ap-northeast-2a", "ap-northeast-2c"]
public_key_material = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCF9MJyO4cfJ1spwEoykRuHsKn9GpXoMb2gHLGxJFc492qspSZittSJUkuI2FxAq1A9022xfNAnNu3RMZGBqreNK9NiczDNoILouYu9/5Ggs/WfibgzQZ3g9ucG2+DTq6UsYtKZKps5gyCve8oWr0cv8Go6DvXEke1eCtvMyyxwR9LlBfNReY2SSNLvu81kNmM7N4jbj8Eky+1IYsZTnjVy2M9MbT+LzzCzERBboJHw9yTB7tYwbxzaAQi1R2xpA23wsiGSlQRdkGDKD0RFAylWZjKtA2FHMmEKj6i3WwGDi26FG70GRakQ9my08g6FMBTfHCnFjfPD7Q8fm54BkxNf rsa-key-20261111"
web_ami             = "ami-0131b10cfa2943e15"
openvpn_ami         = "ami-0f42c79eb0c2339c9"
db_name             = "webDB"
user_name           = "root"
db_instance_class   = "db.t3.micro"
db_engine_version   = "8.4.11"
user_data           = <<-EOT
  #!/bin/bash
  yum install -y httpd php php-mbstring php-pdo php-mysqlnd php-gd wget unzip
  wget -O /tmp/frontend_source.zip https://github.com/csh3031/aws-waf-project/raw/refs/heads/main/frontend_source.zip
  unzip -o /tmp/frontend_source.zip -d /var/www/html/
  systemctl start httpd & systemctl enable httpd
  EOT
